SB DRESSES WEBSITE UPDATE

This folder contains index.html and 20 catalogue images in the images folder.
Upload the CONTENTS of this folder to the root of your GitHub repository (not the folder itself).
Keep the images folder alongside index.html.
WhatsApp enquiries are configured to +91 70037 94053.

To publish: open your GitHub repository, upload index.html and the images folder contents, then commit changes. GitHub Pages will redeploy automatically.
