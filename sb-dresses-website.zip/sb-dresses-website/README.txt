SB DRESSES WEBSITE — QUICK SETUP

Files:
- index.html: complete responsive website (HTML/CSS/JavaScript in one file)

IMPORTANT BEFORE PUBLISHING:
1. Open index.html in a text editor.
2. Find: const WHATSAPP_NUMBER = "";
   Enter the shop WhatsApp number with country code and digits only, e.g. 91XXXXXXXXXX.
3. Find the products array and replace demo names, sizes, prices and image URLs with actual SB DRESSES product details and photos.
4. The current sample product photos are illustrative placeholders, not SB DRESSES stock photos.

PUBLISH FREE WITH GITHUB PAGES:
1. Open the intended repository on GitHub (use only one repository; recommended: sbdresses/Sbdresses).
2. Choose Add file > Upload files.
3. Upload index.html (and this README if desired), then Commit changes.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. GitHub will show the published website URL in the Pages section after deployment.

This is a catalogue and enquiry/order-request website. It does not process online payments or manage inventory. Orders are sent to WhatsApp after the number is configured.
